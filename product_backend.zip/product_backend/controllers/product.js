const productDetailsService = require('../services/product');
const httpStatusCode = require('http-status-codes');
const { responseGenerators, pino } = require('./../lib/utils');
const logger = pino({ level: 'debug' });

const getProductData = async (req, res) => {
    try {
        const userCode = req.headers.user_code;
        const response = await productDetailsService.getProductsData(userCode);
        return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, 'Product data fetched successfully', false));
    } catch (error) {
        logger.warn(`Error while fetch product data. Error: %j %s`, error, error);
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while fetch product data', true))
    }
}

const getProductDataById = async (req, res) => {
    try {
        const productId = Number(req.params.product_id);
        const response = await productDetailsService.getProductDataById(productId);
        return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, 'Product data fetched successfully', false))
    } catch (error) {
        logger.warn(`Error while fetch product data. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while fetch product data', true))
    }
}

const addProductData = async (req, res) => {
    try {
        const userCode = req.headers.user_code;
        const response = await productDetailsService.addProductData(req.body, userCode)
        if (!response || response.length === 0) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, 'Error while adding product data', true))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators(response, httpStatusCode.OK, 'Product details added successfully', false))
    } catch (error) {
        logger.warn(`Error while add product data. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while adding product detail', true))
    }
}

const updateProductData = async (req, res) => {
    try {
        const userCode = req.headers.user_code;
        const productId = Number(req.params.product_id);
        const response = await productDetailsService.editProductData(req.body, productId, userCode)
        if(response.nModified === 0) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, 'No product updated', false))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, 'Product detail updated successfully', false))
    } catch (error) {
        logger.warn(`Error while update product. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while update product detail', true))
    }
}

const deleteProductData = async (req, res) => {
    try {
        const productId = Number(req.query.productId)
        const response = await productDetailsService.deleteProductData(productId)
        if(response === 0) {
            return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, 'No product data deleted', false))
        }
        return res.status(httpStatusCode.OK).send(responseGenerators({}, httpStatusCode.OK, 'Product detail deleted successfully', false))
    } catch (error) {
        logger.warn(`Error while edit product. Error: %j %s`, error, error)
        return res.status(httpStatusCode.INTERNAL_SERVER_ERROR).send(responseGenerators({}, httpStatusCode.INTERNAL_SERVER_ERROR, 'Error while edit product detail', true))
    }
}

module.exports = {
    getProductData,
    addProductData,
    updateProductData,
    deleteProductData,
    getProductDataById
}