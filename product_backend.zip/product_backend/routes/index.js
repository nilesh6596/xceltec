const usersRoute = require('./user');
const productRoute = require('./product');


module.exports = function(app) {
  app.use('/api/project', usersRoute);
  app.use('/api/project', productRoute);
}
