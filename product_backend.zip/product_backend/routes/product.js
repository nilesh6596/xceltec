const express = require('express');
const router = express.Router();
const productController = require('../controllers/product')
const { verifyToken } = require('../middlewares/verifyToken')

router.get('/get/product/data', verifyToken, productController.getProductData);
router.post('/add/product/data', verifyToken, productController.addProductData);
router.put('/update/product/dataById/:product_id', verifyToken, productController.updateProductData);
router.delete('/delete/product/data', verifyToken, productController.deleteProductData);
router.get('/get/product/dataById/:product_id', verifyToken, productController.getProductDataById);

module.exports = router;
