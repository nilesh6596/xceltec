const express = require('express');
const router = express.Router();
const userController = require('../controllers/user')
const { verifyToken } = require('../middlewares/verifyToken')

router.post('/user/signUp', userController.userSignup);
router.post('/user/login', userController.userLogin);

module.exports = router;
