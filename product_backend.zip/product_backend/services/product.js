'use strict'

require('../models/product')
const { pino, connect, bcrypt } = require('../lib/utils')
const logger = pino({ level: 'debug' });

const getProductsData = async (userCode) => {
    try {
        logger.debug('getProductsData() userCode: %s', userCode)
        const db = await connect('Demo')
        const productModel = db.model('product')
        const responseCount = await productModel.count( {})
        if (responseCount < 0) {
              return 'No product exist';
        }
        const response = await productModel.find({}).sort({created_on : -1})
        return [response, responseCount]
    } catch (error) {
        logger.warn(`Error while getProductsData(). Error = %j %s`, error, error)
        throw error
    }
}

const getProductDataById = async (productId) => {
    try {
        logger.debug('getProductDataById() PostId: %s', productId)
        const db = await connect('Demo')
        const postModel = db.model('product')
        const response = await postModel.find({ product_id: productId})
        return response
    } catch (error) {
        logger.warn(`Error while getProductDataById(). Error = %j %s`, error, error)
        throw error
    }
}

const addProductData = async (reqPayload, userCode) => {
    try {
        logger.debug('addProductData() reqPayload: %j, userCode: %s', reqPayload, userCode);
        const db = await connect('Demo');
        const productModel = db.model('product');
        const response = await productModel.insertMany({
            product_name: reqPayload.productName,
            description: reqPayload.description,
            price: reqPayload.price,
            quantity: reqPayload.quantity,
            created_by: userCode
        });
        return response;
    } catch (error) {
        logger.warn(`Error while addProductData(). Error = %j %s`, error, error);
        throw error;
    }
}

const editProductData = async (reqPayload, productId, userCode ) => {
    try {
        logger.debug('editProductData() reqPayload: %j, PostId: %s, userCode: %s', reqPayload, productId, userCode);
        const db = await connect('Demo');
        const productModel = db.model('product');
        const response = await productModel.updateOne({ product_id: productId }, {
            $set: {
                product_name: reqPayload.productName,
                description: reqPayload.description,
                price: reqPayload.price,
                quantity: reqPayload.quantity,
                updated_by: userCode
            }
        })
        return response;
    } catch (error) {
        logger.warn(`Error while editProductData(). Error = %j %s`, error, error);
        throw error;
    }
}


const deleteProductData = async (productId ) => {
    try {
        logger.debug('deleteProductData() Post_id: %s', productId);
        const db = await connect('Demo');
        const productModel = db.model('product');
        const response = await productModel.deleteOne({ product_id: productId })
        return response;
    } catch (error) {
        logger.warn(`Error while deleteProductData(). Error = %j %s`, error, error);
        throw error;
    }
}

module.exports = {
    getProductsData,
    addProductData,
    editProductData,
    deleteProductData,
    getProductDataById
}