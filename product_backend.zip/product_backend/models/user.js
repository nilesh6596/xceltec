'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema
require('mongoose-long')(mongoose)
const SchemaTypes = mongoose.Schema.Types
const { autoIncrement } = require('../lib/utils')

const userdataSchema = new Schema({
  user_id: {
    type: Number,
    required: true
  },
  name: {
    type: String,
    required: false
  },
  email: {
    type: String,
    required: true
  },
  contact: {
    type: Number,
    required: true
  },
  gender: {
    type: String,
    required: true
  },
  hobbies: {
    type: String,
    required: true
  },
  date_of_birth: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  }
})

userdataSchema.plugin(autoIncrement.plugin, {
  model: 'users',
  field: 'user_id',
  startAt: 1
})

module.exports = mongoose.model('users', userdataSchema)
