'use strict'

const mongoose = require('mongoose')
const Schema = mongoose.Schema
require('mongoose-long')(mongoose)
const SchemaTypes = mongoose.Schema.Types
const { autoIncrement } = require('../lib/utils')

const productDataSchema = new Schema({
  product_id: {
    type: Number,
    required: true
  },
  product_name: {
    type: String,
    required: false
  },
  description: {
    type: String,
    required: true
  },
  price: {
    type: Number,
    required: true
  },
  quantity: {
    type: Number,
    required: true
  }
})

productDataSchema.plugin(autoIncrement.plugin, {
  model: 'product',
  field: 'product_id',
  startAt: 1
})

module.exports = mongoose.model('product', productDataSchema)
