import { Injectable, Inject } from '@angular/core';
import { map } from 'rxjs/operators';
import { Headers, RequestOptions, Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

constructor(
    private http: Http,
    // @Inject(LOCAL_STORAGE)private _sessionstorage: WebStorageService,
  ) { }

  userLoginAPI(body) {
    const url = 'http://localhost:3000/api/project/user/login';
    return this.http.post(url, body)
    .pipe(map(response => {
      return response.json();
    }));
  }
  getProductDataAPI() {
    const params = {};
    const url = 'http://localhost:3000/api/project/get/product/data';
    return this.http.get(url, this.setHeaderWithParams(params))
    .pipe(map(response => {
      return response.json();
    }));
  }

  getProductDataByIdAPI(productId) {
    const params = {};
    params['productId'] = productId;
    let url = 'http://localhost:3000/api/project/get/product/dataById/:product_id';
    url = url.replace(':product_id', productId);
    return this.http.get(url, this.setHeaderWithParams(params))
    .pipe(map(response => {
      return response.json();
    }));
  }

  editProductDataAPI(body, productId) {
    const params = {};
    let url = 'http://localhost:3000/api/project/update/product/dataById/:product_id';
    url = url.replace(':product_id', productId);
    return this.http.put(url, body, this.setHeaderWithParams(params))
    .pipe(map(response => {
      return response.json();
    }));
  }

  addProductDataAPI (body) {
    const params = {};
    const url = 'http://localhost:3000/api/project/add/product/data';
    return this.http.post(url, body, this.setHeaderWithParams(params))
      .pipe(map(response => {
        return response.json();
      }));
  }

  deleteProductDataAPI(productId) {
    const params = {};
    params['productId'] = productId;
    const url = 'http://localhost:3000/api/project/delete/product/data';
    return this.http.delete(url, this.setHeaderWithParams(params))
    .pipe(map(response => {
      return response.json();
    }));
  }

  setHeaderWithParams(params) {
    const headers = new Headers();
    const userCode = localStorage.getItem('userCode');
    const authToken = localStorage.getItem('token');
    headers.append('user_code', userCode);
    headers.append('token', authToken);
    return new RequestOptions({ headers: headers, params: params });
  }
}
