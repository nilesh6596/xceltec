import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public requestJson = this.createRequestJson();
  public userName = 'userName';
  public password = 'password';
  public isLoggedIn = false;

  constructor(
    private router: Router,
    private _loginService: LoginService,
  ) { }

  ngOnInit(): void {

  }

  createRequestJson() {
    const requestJson = {};
    requestJson[this.userName] = '';
    requestJson[this.password] = '';
    return requestJson;
  }

  submit(form) {
    if (!form.invalid) {
      const formValues = form.value;
      this.loginUser(formValues);
    }
  }

  loginUser(formValues) {
    return new Promise(async (resolve, reject) => {
      const body = {};
      body[this.userName] = formValues.userName;
      body[this.password] = formValues.password;
      this._loginService.userLoginAPI(body).subscribe(async (response: any) => {
        if (response) {
          this.isLoggedIn = true;
          localStorage.setItem('UserLoggedIn', JSON.stringify(this.isLoggedIn));
          localStorage.setItem('userCode', response.data[0].user_id);
          localStorage.setItem('token', response.token);
          localStorage.setItem('name', response.data[0].name);
          this.router.navigate(['./home']);
        }
      })
    });
  }

}
