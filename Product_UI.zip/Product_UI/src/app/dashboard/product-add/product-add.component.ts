import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/login/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-add',
  templateUrl: './product-add.component.html',
  styleUrls: ['./product-add.component.scss']
})
export class ProductAddComponent implements OnInit {

  public requestJson = this.createRequestJson();
  public categoryList: any[];
  public status: any;

  constructor(
    private _router: Router,
    private loginService: LoginService
  ) { }

  ngOnInit() {
  }

  createRequestJson() {
    const requestJson = {};
    requestJson['name'] = '';
    requestJson['description'] = '';
    requestJson['price'] = '';
    requestJson['quantity'] = '';
    return requestJson;
  }


  submit(form) {
    if (form.valid) {
        const formValues = form.value;
        this.addProductData(formValues);
    } else {
        this.setFocusToInvalidElement(form);
      }
  }

  // focus to invalid input fields
  setFocusToInvalidElement(form) {
    if (!form.valid) {
      let target;
      target = document.getElementsByClassName('ng-invalid')[1];
      if (target) {
        target.focus();
      }
    }
  }


 // add post data api call
 addProductData(formValues) {
    return new Promise(async (resolve, reject) => {
          const body = {};
          body['productName'] = formValues.name;
          body['description'] = formValues.description;
          body['price'] = formValues.price;
          body['quantity'] = formValues.quantity;
          this.loginService.addProductDataAPI(body).subscribe(async (response: any) => {
            if (response && response.status_code === 200) {
              this._router.navigate(['./home']);
            }
            resolve(response);
          },
          error => {
            alert('Something went wrong..!!');
          });
        });
  }


}
