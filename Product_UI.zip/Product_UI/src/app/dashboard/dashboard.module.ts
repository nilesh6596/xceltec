import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductComponent } from './product/product.component';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { dashboardrouting } from './dashboard-routing.module';
import { ProductAddComponent } from './product-add/product-add.component';



@NgModule({
  declarations: [ProductComponent, ProductAddComponent],
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    dashboardrouting,
    FormsModule,
  ]
})
export class DashboardModule { }
