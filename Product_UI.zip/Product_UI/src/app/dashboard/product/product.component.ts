import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/login/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
})
export class ProductComponent implements OnInit {
  public isResource = false;
  public productData = [];
  public productDataOfId = [];
  constructor(private router: Router, private loginService: LoginService) {}

  ngOnInit(): void {
    this.getProductList();
  }

  async getProductList() {
    return new Promise(async (resolve, reject) => {
      this.loginService.getProductDataAPI().subscribe(async (response: any) => {
        if (response) {
          this.productData = response.data[0];
        }
      });
    });
  }

  closeChatDilog() {
    localStorage.removeItem('productId');
    document.getElementById('myModal').style.display = 'none';
  }

  editProductData(productId) {
    document.getElementById('myModal').style.display = 'block';
    localStorage.setItem('productId', productId);
    this.getPtDroducataById(productId);
  }

  getPtDroducataById(productId) {
    return new Promise(async (resolve, reject) => {
      this.loginService.getProductDataByIdAPI(productId).subscribe(
        async (response: any) => {
          if (response && response.status_code === 200) {
            this.productDataOfId = response.data;
          }
          resolve(response);
        },
        (error) => {
          alert('Something went wrong..!!');
        }
      );
    });
  }

  submit(form) {
    if (form.valid) {
      const formValues = form.value;
      this.updateProductData(formValues);
    } else {
      this.setFocusToInvalidElement(form);
    }
  }

  setFocusToInvalidElement(form) {
    if (!form.valid) {
      let target;
      target = document.getElementsByClassName('ng-invalid')[1];
      if (target) {
        target.focus();
      }
    }
  }

  async updateProductData(formValues) {
    return new Promise(async (resolve, reject) => {
      const body = {};
      body['productName'] = formValues.name;
      body['description'] = formValues.description;
      body['price'] = formValues.price;
      body['quantity'] = formValues.quantity;
      const productId = localStorage.getItem('productId');
      this.loginService.editProductDataAPI(body, productId)
        .subscribe(async (response: any) => {
          if (response) {
            document.getElementById('myModal').style.display = 'none';
            localStorage.removeItem('productId');
            this.getProductList();
          }
        });
    });
  }

  async deleteProductData(productId) {
    return new Promise(async (resolve, reject) => {
      this.loginService
        .deleteProductDataAPI(productId)
        .subscribe(async (response: any) => {
          if (response) {
            this.getProductList();
          }
        });
    });
  }
}
