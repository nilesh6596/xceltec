import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { ProductComponent } from './product/product.component';
import { ProductAddComponent } from './product-add/product-add.component';

export const dashboardRoutes: Routes = [

  { path: '', component: DashboardComponent,
      children: [
        { path: '', redirectTo: 'productManagement'},
        { path: 'productManagement', component: ProductComponent, pathMatch: 'full' },
        { path: 'productForm', component: ProductAddComponent, pathMatch: 'full' },
      ]
  },
];
export const dashboardrouting = RouterModule.forChild(dashboardRoutes);

@NgModule({
  imports: [dashboardrouting],
  exports: [RouterModule]
})

export class DashboardRoutingModule { }
